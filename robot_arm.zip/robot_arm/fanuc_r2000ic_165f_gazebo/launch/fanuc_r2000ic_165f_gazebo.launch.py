
import os
from launch_ros.actions import Node
from launch import LaunchDescription
from launch.substitutions import Command
from launch.actions import ExecuteProcess
from launch.substitutions import Command, FindExecutable, LaunchConfiguration
from launch_ros.parameter_descriptions import ParameterValue

from ament_index_python.packages import get_package_share_directory
from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_demo_launch


def generate_launch_description():
    # robot model to option m1013 or a0912

    robot_model = 'r2000ic165f'
    # robot_model = 'a0912'

    xacro_file = get_package_share_directory('fanuc_r2000ic_165f_description') + '/urdf/' + robot_model + '.urdf.xacro'
    #xacro_file = get_package_share_directory('my_doosan_pkg') + '/description' + '/xacro/' + robot_model + '.urdf.xacro'


    robot_description = ParameterValue(Command(['xacro ', xacro_file]),
                                       value_type=str)
    print(xacro_file)
    # Robot State Publisher
    robot_state_publisher = Node(package='robot_state_publisher',
                                 executable='robot_state_publisher',
                                 name='robot_state_publisher',
                                 output='both',
                                 parameters=[{'robot_description': robot_description
                                              }])

    
    # Spawn the robot in Gazebo
    spawn_entity_robot = Node(package='gazebo_ros',
                              executable='spawn_entity.py',
                              arguments=['-entity', robot_model, '-topic', 'robot_description'],
                              output='screen')
    
    spawn_controller1 = Node(
        package="controller_manager",
        executable="spawner",
        arguments=['joint_state_broadcaster'],
        output="screen",
    )


    spawn_controller2 = Node(
        package="controller_manager",
        executable="spawner",
        arguments=['joint_trajectory_controller'],
        output="screen",
    )
    

    # Start Gazebo with my empty world
    world_file_name = 'empty_world.world'
    world = os.path.join(get_package_share_directory('fanuc_r2000ic_165f_gazebo'), 'worlds', world_file_name)
    gazebo_node = ExecuteProcess(cmd=['gazebo', '--verbose', world, '-s', 'libgazebo_ros_factory.so'], output='screen')
    
    #return LaunchDescription([robot_state_publisher])
    return LaunchDescription([robot_state_publisher, spawn_entity_robot, gazebo_node, spawn_controller1,spawn_controller2])
    #return LaunchDescription([robot_state_publisher, spawn_entity_robot, gazebo_node])
