
import os
from launch_ros.actions import Node
from launch import LaunchDescription
from launch.substitutions import Command
from launch.actions import ExecuteProcess
from launch.substitutions import Command, FindExecutable, LaunchConfiguration
from launch_ros.parameter_descriptions import ParameterValue

from ament_index_python.packages import get_package_share_directory
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():

    robot_gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare('fanuc_r2000ic_165f_gazebo'), 'launch', 'fanuc_r2000ic_165f_gazebo.launch.py'])),
    )

    robot_moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([FindPackageShare('fanuc_r2000ic_165f_moveit_config'), 'launch', 'demo.launch.py'])),
    )


    #return LaunchDescription([robot_state_publisher])
    #return LaunchDescription([robot_state_publisher, spawn_entity_robot, gazebo_node, spawn_controller1,spawn_controller2])
    return LaunchDescription([robot_gazebo_launch,robot_moveit_launch])