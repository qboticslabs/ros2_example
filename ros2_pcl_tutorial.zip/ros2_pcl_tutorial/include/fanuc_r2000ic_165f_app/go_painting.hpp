#ifndef GO_PAINTING_HPP
#define GO_PAINTING_HPP


#include <memory>

#include <rclcpp/rclcpp.hpp>
#include "tf2/exceptions.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_broadcaster.h"

#include "geometry_msgs/msg/transform_stamped.hpp"

#include "sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/header.hpp"
#include <chrono>

#include "sensor_msgs/msg/point_cloud2.hpp"
#include "sensor_msgs/point_cloud2_iterator.hpp"
#include "pcl_conversions/pcl_conversions.h"

#include <cv_bridge/cv_bridge.h> // cv_bridge converts between ROS 2 image messages and OpenCV image representations.
#include <image_transport/image_transport.hpp> // Using image_transport allows us to publish and subscribe to compressed image streams in ROS2
#include <opencv2/opencv.hpp> // We include everything about OpenCV as we don't care much about compilation time at the moment.

#include <ament_index_cpp/get_package_share_directory.hpp>

#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_visual_tools/moveit_visual_tools.h>

#include <moveit/moveit_cpp/moveit_cpp.h>
#include <moveit/moveit_cpp/planning_component.h>

#include <thread>



using namespace std::chrono_literals;

static const rclcpp::Logger LOGGER = rclcpp::get_logger("move_group_demo");
using moveit::planning_interface::MoveGroupInterface;

using std::placeholders::_1;



class Traj
{

public:
    Traj();
    cv::Mat read_img_parts(std::string part_name);
    void image_cb(const sensor_msgs::msg::Image::SharedPtr msg); 
    void pcl_cb(const sensor_msgs::msg::PointCloud2::SharedPtr msg); 
    void on_timer();
    void publish_tf(void);
    void publish_tf_part(std::string part,int row_step,int col_step, float height_from_body);
    geometry_msgs::msg::TransformStamped getCurrentPose(void);
    geometry_msgs::msg::TransformStamped getTransform(std::string target_frame,std::string base_frame);

    void update();
    void update1();
    void move_trajectory(float step,float no_parts,int scale_axis_x,int scale_axis_y,int scale_axis_z);
    void move_pose(float x,float y,float z);
    geometry_msgs::msg::Pose pixel_waypoint(int x, int y);
    void thread_loop();

private:

  std::shared_ptr<rclcpp::Node> node = nullptr;
  std::shared_ptr<MoveGroupInterface> move_group_interface = nullptr;
  std::shared_ptr<rclcpp::WallRate> loop_rate = nullptr;

  //Camera to object
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_{nullptr};
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;

  //Tool0 to object
  std::shared_ptr<tf2_ros::TransformListener> tool0_tf_listener_{nullptr};
  std::unique_ptr<tf2_ros::Buffer> tool0_tf_buffer_;

  rclcpp::TimerBase::SharedPtr timer_{nullptr};

  std::string fromFrameRel ;
  std::string toFrameRel ;

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr subscription_img;
  rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_pcl;
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud = nullptr;

  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tool0_tf_broadcaster_;

  geometry_msgs::msg::TransformStamped current_pose;
  std::string package_path; 


  std::shared_ptr<moveit_visual_tools::MoveItVisualTools> moveit_visual_tools = nullptr;
  std::shared_ptr<moveit_cpp::MoveItCpp> moveit_cpp_ptr = nullptr;
  moveit::core::RobotModelConstPtr robot_model_ptr = nullptr;
  const moveit::core::JointModelGroup *joint_model_group_ptr;

  std::shared_ptr<std::thread> main_thread = nullptr;


  //cv::Mat part_1, part_2, part_3, part_4, part_5, part_6;
  int r_,g_,b_;
  //int i_obj,j_obj;



};

#endif