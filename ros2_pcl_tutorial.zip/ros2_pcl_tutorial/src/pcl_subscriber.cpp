#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"


#include "sensor_msgs/msg/point_cloud2.hpp"
#include "sensor_msgs/point_cloud2_iterator.hpp"
#include "pcl_conversions/pcl_conversions.h"
#include <pcl/filters/voxel_grid.h>


using std::placeholders::_1;

class MinimalSubscriber : public rclcpp::Node
{
  public:
    MinimalSubscriber()
    : Node("pcl_subscriber")
    {
    
      publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("topic_out", 10);
      
          
      subscription_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
      "topic", 10, std::bind(&MinimalSubscriber::topic_callback, this, _1));
    }

  private:
    void topic_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg) const
    {
      RCLCPP_INFO(this->get_logger(), "I heard: ");
      
      pcl::PointCloud<pcl::PointXYZ> cloud;
      pcl::PointCloud<pcl::PointXYZ> cloud_filtered;


      auto output = sensor_msgs::msg::PointCloud2();        
      pcl::fromROSMsg(*msg, cloud);


      pcl::VoxelGrid<pcl::PointXYZ> vox_obj;
      vox_obj.setInputCloud (cloud.makeShared());

      vox_obj.setLeafSize (0.1f, 0.1f, 0.1f);
      vox_obj.filter(cloud_filtered);


      pcl::toROSMsg(cloud_filtered, output);
      output.header.frame_id = "point_cloud";

      publisher_->publish(output);
      
    
      
      
    }
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_;
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher_;    
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalSubscriber>());
  rclcpp::shutdown();
  return 0;
}
