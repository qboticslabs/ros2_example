#include <memory>

#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
static const rclcpp::Logger LOGGER = rclcpp::get_logger("move_group_demo");
int main(int argc, char * argv[])
{

  // Initialize ROS and create the Node
  rclcpp::init(argc, argv);
  auto const node = std::make_shared<rclcpp::Node>(
    "hello_moveit",
    rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)
     
  );

  // Create a ROS logger
  auto const logger = rclcpp::get_logger("hello_moveit");
   
using moveit::planning_interface::MoveGroupInterface;
auto move_group_interface = MoveGroupInterface(node, "arm");


while(1)
{
auto current_pose = move_group_interface.getCurrentPose();

std::cout << "x:" << current_pose.pose.position.x << std::endl;
std::cout << "y:" << current_pose.pose.position.y << std::endl;
std::cout << "z:" << current_pose.pose.position.z << std::endl;

std::vector<geometry_msgs::msg::Pose> waypoints;
float x,xx,yy,zz;
std::cout<<"enter the value of ww,xx,yy,zz"<<std::endl;
std::cin>>x>>xx>>yy>>zz;
 
  geometry_msgs::msg::Pose msg;
  msg.orientation.x = x;

  msg.position.x = xx;
  msg.position.y = yy;
  msg.position.z = zz;
  waypoints.push_back(msg); 
  moveit_msgs::msg::RobotTrajectory trajectory;
  double fraction = move_group_interface.computeCartesianPath(waypoints, 0.01, 0.0, trajectory);
  std::cout<<"fraction value is %f"<<fraction<<std::endl;
   move_group_interface.execute(trajectory); 
  //return msg;

}  // Shutdown ROS
  rclcpp::shutdown();
  return 0;
}
